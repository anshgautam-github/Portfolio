import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import "./freefall.css";

gsap.registerPlugin(ScrollTrigger);

/*
  <Freefall /> - a scroll-driven deck of four abstractions.

  The section pins. Scrolling advances a continuous value t (0 -> 10). Card i sits at depth d = i - t:
    d > 0   still waiting: stacked up and away (each one a little smaller, a little higher, a little more tilted back)
    d = 0   the card in front
    d < 0   already read: it drops off the bottom edge, accelerating, and leaves
  Everything is written straight to the card elements each frame (no React renders while scrolling);
  React state only changes when the "current" card changes (counter, name, glow colour).

  Art lives in /public/freefall/01..11.jpg - swap them for your own images any time (same file names).
*/

const CARDS = [
  { art: 1, n: "Aurora", tag: "AURORA", text: "Curtains of light drifting over a quiet horizon.", glow: "#2fd9b8" },
  { art: 5, n: "Gossamer", tag: "SILK", text: "Threads of colour drifting like morning mist.", glow: "#5fd6c4" },
  { art: 6, n: "Basin", tag: "POUR", text: "Paint poured into water and caught mid-swirl.", glow: "#2f64e0" },
  { art: 8, n: "Delta", tag: "MARBLE", text: "Rivers of colour braiding through stone.", glow: "#2fa4d8" },
];
const N = CARDS.length;
const WORD = "Freefall".split("");
const WORD_COLORS = ["#3a2cff", "#5a2fe6", "#7b2dcc", "#9e2bb0", "#c02e92", "#dc3f75", "#ea5a58", "#f26a45"];

const pad = (n) => String(n).padStart(2, "0");
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const sstep = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
const smoother = (f) => f * f * f * (f * (f * 6 - 15) + 10); // dwell on each card, move quickly between them
const BASE = import.meta.env.BASE_URL || "/";

export default function Freefall() {
  const root = useRef(null);
  const deckRef = useRef(null);
  const fillRef = useRef(null);
  const dotRef = useRef(null);
  const api = useRef({ step() {} });
  const [active, setActive] = useState(0);

  useLayoutEffect(() => {
    const el = root.current;
    const deck = deckRef.current;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const cleanups = [];

    const ctx = gsap.context(() => {
      const cards = gsap.utils.toArray("[data-card]", el);
      const arts = cards.map((c) => c.querySelector("[data-art]"));
      const caps = cards.map((c) => c.querySelector("[data-cap]"));
      const shades = cards.map((c) => c.querySelector("[data-shade]"));
      const sheens = cards.map((c) => c.querySelector("[data-sheen]"));
      const intro = cards.map(() => ({ v: reduce ? 1 : 0 }));
      const prog = { t: 0 };
      let H = 800, cw = 300, Y1 = 150, mobile = false;
      let current = -1;
      let st = null;

      const layout = () => {
        H = el.clientHeight;
        const Wd = el.clientWidth;
        mobile = Wd <= 900;
        cw = mobile ? Math.min(Wd * 0.62, H * 0.3) : Math.min(H * 0.39, deck.clientWidth * 0.9);
        const ch = cw * 1.14;
        const slot = mobile ? H * 0.52 : H * 0.41;
        Y1 = (mobile ? 0.15 : 0.192) * H;
        el.style.setProperty("--cw", `${cw.toFixed(1)}px`);
        cards.forEach((c) => {
          c.style.width = `${cw}px`;
          c.style.height = `${ch}px`;
          c.style.top = `${slot}px`;
          c.style.marginLeft = `${-cw / 2}px`;
        });
      };

      const render = () => {
        const t = prog.t;
        const k = Math.min(Math.floor(t), N - 1);
        const te = k >= N - 1 ? N - 1 : k + smoother(t - k);

        for (let i = 0; i < N; i++) {
          const d = i - te;
          const c = cards[i];
          let y, s, rx, op = 1, z;
          if (d >= 0) {
            const r = 0.38;
            y = (-Y1 * (1 - Math.pow(r, d))) / (1 - r);
            s = 0.74 + 0.26 * Math.pow(0.5, d);
            rx = 4 + 9 * (1 - Math.pow(0.55, d));
            op = 1 - sstep(4.6, 7.2, d);
            z = 500 - i;
          } else {
            const u = -d;
            y = H * (0.26 * u + 0.5 * u * u); // gravity: it accelerates and is gone off the bottom edge by u ~ 1
            s = 1 + 0.14 * u;
            rx = 4 + 8 * u;
            op = 1 - sstep(0.9, 1.05, u);
            z = 700 - i;
          }
          // the whole deck drops in from above on first view
          const iv = intro[i].v;
          y -= (1 - iv) * H * 1.15;
          op *= clamp(iv * 3, 0, 1);

          if (op <= 0.003) {
            if (c.style.visibility !== "hidden") c.style.visibility = "hidden";
            continue;
          }
          if (c.style.visibility !== "visible") c.style.visibility = "visible";
          c.style.opacity = op.toFixed(3);
          c.style.zIndex = z;
          c.style.transform = `translate3d(0, ${y.toFixed(1)}px, 0) rotateX(${rx.toFixed(2)}deg) scale(${s.toFixed(4)})`;
          // inner art drifts a touch against the card (parallax), captions only read on the front card
          arts[i].style.transform = `translate3d(0, ${(clamp(d, -1.5, 3) * -16).toFixed(1)}px, 0) scale(1.12)`;
          caps[i].style.opacity = (1 - clamp(d * 2.4, 0, 1)).toFixed(3);
          shades[i].style.opacity = clamp(d * 0.13, 0, 0.55).toFixed(3);
          sheens[i].style.transform = `translate3d(${(clamp(d, -1.2, 1.2) * 90).toFixed(1)}%, 0, 0)`;
        }

        // rail
        const p = t / (N - 1);
        if (fillRef.current) fillRef.current.style.transform = `scaleY(${p.toFixed(4)})`;
        if (dotRef.current) dotRef.current.style.top = `${(p * 100).toFixed(3)}%`;
        const a = clamp(Math.round(te), 0, N - 1);
        if (a !== current) {
          current = a;
          setActive(a);
          el.style.setProperty("--glow", CARDS[a].glow);
        }
      };

      layout();
      render();

      /* ---- the pinned scroll ---- */
      if (!reduce) {
        const tl = gsap.timeline({
          scrollTrigger: {
            trigger: el,
            start: "top top",
            end: () => `+=${Math.round((N - 1) * window.innerHeight * 0.85 + window.innerHeight * 0.25)}`,
            pin: true,
            scrub: 0.7,
            anticipatePin: 1,
            invalidateOnRefresh: true,
            onRefreshInit: layout,
          },
        });
        st = tl.scrollTrigger;
        tl.to(prog, { t: N - 1, duration: 0.9, ease: "none", onUpdate: render });
        tl.to({}, { duration: 0.1 }); // hold on the last card
      }

      /* ---- entrance: the cards fall in, the headline letters drop ---- */
      const letters = gsap.utils.toArray("[data-letter]", el);
      const enterEls = gsap.utils.toArray("[data-enter]", el);
      const playIntro = () => {
        if (reduce) return;
        gsap.to(intro, { v: 1, duration: 1.25, ease: "power3.out", stagger: { each: 0.085, from: "end" }, onUpdate: render });
        gsap.fromTo(letters, { yPercent: -150, rotate: -16, autoAlpha: 0 }, { yPercent: 0, rotate: 0, autoAlpha: 1, duration: 1.1, ease: "bounce.out", stagger: 0.05, delay: 0.15 });
        gsap.fromTo(enterEls, { y: 30, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: 0.9, ease: "power3.out", stagger: 0.1, delay: 0.1 });
      };
      if (!reduce) {
        gsap.set(letters, { autoAlpha: 0 });
        gsap.set(enterEls, { autoAlpha: 0 });
        const sti = ScrollTrigger.create({ trigger: el, start: "top 80%", once: true, onEnter: playIntro });
        const io = new IntersectionObserver((es) => {
          if (es.some((x) => x.isIntersecting)) {
            playIntro();
            io.disconnect();
            sti.kill();
          }
        }, { threshold: 0.25 });
        io.observe(el);
        cleanups.push(() => io.disconnect());
      }

      /* ---- pointer: the vanishing point drifts a little with the cursor ---- */
      const po = { x: 50, y: 40 };
      const onMove = (e) => {
        if (mobile) return;
        const r = el.getBoundingClientRect();
        const nx = (e.clientX - r.left) / r.width - 0.5;
        const ny = (e.clientY - r.top) / r.height - 0.5;
        gsap.to(po, {
          x: 50 + nx * 22,
          y: 40 + ny * 16,
          duration: 0.9,
          ease: "power3.out",
          overwrite: true,
          onUpdate: () => (deck.style.perspectiveOrigin = `${po.x.toFixed(1)}% ${po.y.toFixed(1)}%`),
        });
      };
      el.addEventListener("pointermove", onMove);
      cleanups.push(() => el.removeEventListener("pointermove", onMove));

      /* ---- the button: scroll to the next card ---- */
      api.current.step = (dir = 1) => {
        if (!st) return;
        const at = Math.round(prog.t);
        const to = clamp(at + dir, 0, N - 1);
        const span = st.end - st.start;
        const target = st.start + ((to / (N - 1)) * 0.9 * span);
        window.scrollTo({ top: target, behavior: "smooth" });
      };

      const ro = new ResizeObserver(() => {
        layout();
        render();
      });
      ro.observe(el);
      cleanups.push(() => ro.disconnect());
    }, el);

    return () => {
      cleanups.forEach((f) => f());
      ctx.revert();
    };
  }, []);

  const c = CARDS[active];

  return (
    <section ref={root} className="ff" aria-label="Gallery - In Freefall">
      <div className="ff-bg" aria-hidden="true" />
      <div className="ff-glow" aria-hidden="true" />

      <div className="ff-left">
        <div className="ff-eyebrow" data-enter>
          <i />
          <span>Gallery · Vol. 01</span>
        </div>
        <h2 className="ff-title" aria-label="In Freefall">
          <span className="ff-in" aria-hidden="true">
            {"In".split("").map((ch, i) => (
              <span key={i} className="ff-letter" data-letter>
                {ch}
              </span>
            ))}
          </span>
          <span className="ff-fall" aria-hidden="true">
            {WORD.map((ch, i) => (
              <span key={i} className="ff-letter" data-letter style={{ color: WORD_COLORS[i] }}>
                {ch}
              </span>
            ))}
          </span>
        </h2>
        <p className="ff-lede" data-enter>
          Four abstractions caught mid-drop. Scroll, and each one folds over the crest and cascades straight down into the pit.
        </p>
        <button type="button" className="ff-cta" data-enter onClick={() => api.current.step(1)}>
          <span>Explore the deck</span>
          <b aria-hidden="true">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 12h16M14 6l6 6-6 6" />
            </svg>
          </b>
        </button>
      </div>

      <div ref={deckRef} className="ff-deck">
        {CARDS.map((card, i) => (
          <article key={card.n} className="ff-card" data-card aria-label={`${card.n} - ${card.tag}`}>
            <div className="ff-art" data-art style={{ backgroundImage: `url(${BASE}freefall/${pad(card.art)}.jpg)` }} />
            <i className="ff-sheen" data-sheen />
            <i className="ff-shade" data-shade />
            <span className="ff-chip">
              {pad(i + 1)} / {N}
            </span>
            <span className="ff-tag">{card.tag}</span>
            <div className="ff-cap" data-cap>
              <small>Chapter {pad(i + 1)}</small>
              <h3>{card.n}</h3>
              <p>{card.text}</p>
            </div>
          </article>
        ))}
      </div>

      <aside className="ff-rail" aria-hidden="true">
        <div className="ff-num">
          <span key={active} className="ff-num-in">
            {pad(active + 1)}
          </span>
          <small>/{N}</small>
        </div>
        <div className="ff-line">
          <i ref={fillRef} className="ff-line-fill" />
          {CARDS.map((_, i) => (
            <b key={i} className="ff-tick" style={{ top: `${(i / (N - 1)) * 100}%` }} />
          ))}
          <em ref={dotRef} className="ff-dot" />
        </div>
        <div className="ff-name">
          <span key={active}>{c.n}</span>
        </div>
      </aside>
    </section>
  );
}
